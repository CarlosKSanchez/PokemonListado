import { Pokemon } from './../../interfaces/pokemon.interface';
import { Component, Input } from '@angular/core';


@Component({
  selector: 'app-lista',
  templateUrl: './listapokemon.component.html',
  styleUrls: ['./listapokemon.component.css']
})

export class ListaPokemonComponent {
    public listado: Pokemon[]
    @Input() setlistado(e: Pokemon[]) {
        console.log('entro al input',e);
        this.listado = e;
    }
    constructor(){}
}