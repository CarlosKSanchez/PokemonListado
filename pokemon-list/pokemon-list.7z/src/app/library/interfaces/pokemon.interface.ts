export interface Pokemon 
{
     nombre: string; 
     url: string; 
}