import { HttpClient } from '@angular/common/http';
import { Component } from '@angular/core';
import { Pokemon } from './library/interfaces/pokemon.interface';


@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  title = 'pokemon-list';
  
  public lista: Pokemon[] 
  sprites: Array<{nombre: string, sprite:string}>

  constructor(private http: HttpClient){}
  ngOnInit(){
    this.GetPokeList()
    this.ExtractPokemon()
  }
  
  GetPokeList(){
    return this.http.get("https://pokeapi.co/api/v2/pokemon?limit=100&offset=0")
  }

  async ExtractPokemon(){

    await this.GetPokeList().subscribe((res:any) => 
    {
      this.lista = res.results as Pokemon[]

      // console.log(this.lista)

      this.lista.forEach(pokemon => {
        console.log(pokemon)
        this.http.get(pokemon.url).subscribe((res:any) =>
        {
          // console.log({nombre: pokemon.nombre ,sprite: res.sprites.other.dream_world.front_default}); 
          // this.sprites.push({nombre: pokemon.nombre ,sprite: res.sprites.other.dream_world.front_default})
        })
        // let sprite = json.sprites.other.dream_world.front_default
        // this.sprites.push()
      });
    })
  }
}
